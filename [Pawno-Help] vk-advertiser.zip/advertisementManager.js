const { log } = require('./logger');
const { getActiveMessage, saveConfig, getNextMessage } = require('./config');

class AdvertisementManager {
  constructor(vk, config) {
    this.vk = vk;
    this.config = config;
    this.intervalId = null;
    this.isProcessing = false;
    this.currentMessageIndex = 0;
  }

  start() {
    if (this.intervalId) {
      log('Попытка запустить рассылку, когда она уже запущена', this.config);
      return false;
    }

    log(`Запуск рассылки с интервалом ${this.config.delay} секунд`, this.config);
    
    this.currentMessageIndex = 0;

    this.sendMessages();

    this.intervalId = setInterval(() => {
      this.sendMessages();
    }, this.config.delay * 1000);

    return true;
  }

  stop() {
    if (!this.intervalId) {
      log('Попытка остановить рассылку, когда она не запущена', this.config);
      return false;
    }

    log('Остановка рассылки', this.config);
    clearInterval(this.intervalId);
    this.intervalId = null;
    return true;
  }

  validateConfig() {
    if (!this.config.isRunning) {
      return { isValid: false, reason: 'Рассылка не активирована' };
    }
    
    if (this.config.chats.length === 0) {
      return { isValid: false, reason: 'Список чатов пуст' };
    }
    
    if (this.config.messages.length === 0 && !this.config.message) {
      return { isValid: false, reason: 'Нет сообщений для рассылки' };
    }
    
    if (this.config.useMultipleMessages && this.config.activeMessageIndexes.length === 0) {
      return { isValid: false, reason: 'Режим нескольких сообщений включен, но не выбраны активные сообщения' };
    }
    
    return { isValid: true };
  }

  async sendMessages() {
    if (this.isProcessing) {
      log('Пропуск рассылки - предыдущая еще выполняется', this.config);
      return;
    }
    
    try {
      this.isProcessing = true;
      
      const validation = this.validateConfig();
      if (!validation.isValid) {
        log(`Рассылка пропущена: ${validation.reason}`, this.config);
        return;
      }

      log(`Начало рассылки рекламы по ${this.config.chats.length} чатам`, this.config);
      
      let messageToSend;
      if (this.config.useMultipleMessages) {
        messageToSend = getNextMessage(this.config, this.currentMessageIndex);
        
        this.currentMessageIndex = (this.currentMessageIndex + 1) % this.config.activeMessageIndexes.length;
        
        log(`Используется сообщение ${this.currentMessageIndex} из ${this.config.activeMessageIndexes.length} в режиме множественной рассылки`, this.config);
      } else {
        messageToSend = getActiveMessage(this.config);
      }
      
      if (!messageToSend) {
        log('Рассылка пропущена: активное сообщение не найдено', this.config);
        return;
      }

      let successCount = 0;
      let errorCount = 0;
      const removedChats = [];

      for (const chatId of [...this.config.chats]) {
        try {
          await this.vk.api.messages.send({
            peer_id: chatId,
            message: messageToSend,
            random_id: Math.floor(Math.random() * 1000000)
          });
          
          log(`Сообщение успешно отправлено в чат ${chatId}`, this.config);
          successCount++;
          
          await new Promise(resolve => setTimeout(resolve, 1000));
        } catch (error) {
          log(`Ошибка при отправке сообщения в чат ${chatId}: ${error.message}`, this.config);
          errorCount++;
          
          if (this.isAccessError(error)) {
            log(`Чат ${chatId} удален из списка рассылки из-за ошибки доступа`, this.config);
            const index = this.config.chats.indexOf(chatId);
            if (index !== -1) {
              this.config.chats.splice(index, 1);
              removedChats.push(chatId);
            }
          }
        }
      }

      if (removedChats.length > 0) {
        saveConfig(this.config);
      }

      log(`Рассылка рекламы завершена: успешно - ${successCount}, с ошибками - ${errorCount}, удалено чатов - ${removedChats.length}`, this.config);
    } catch (error) {
      log(`Критическая ошибка при рассылке: ${error.message}`, this.config);
    } finally {
      this.isProcessing = false;
    }
  }

  isAccessError(error) {
    return error.code === 917 || error.code === 15 || error.code === 7;
  }
}

module.exports = AdvertisementManager; 