require('dotenv').config();
const { VK } = require('vk-io');
const { loadConfig, saveConfig, isAdmin } = require('./config');
const { log } = require('./logger');
const AdvertisementManager = require('./advertisementManager');
const commands = require('./commands');

const config = loadConfig();

const vk = new VK({
  token: config.token
});

const advertisementManager = new AdvertisementManager(vk, config);

if (!config.token) {
  console.error('Ошибка: VK токен не указан в файле конфигурации.');
  console.log('Используйте команду /settoken [токен] для установки токена через бота.');
}

const COMMAND_HANDLERS = {
  '/start': { handler: commands.startCommand, needsAdvertisementManager: true },
  '/stop': { handler: commands.stopCommand, needsAdvertisementManager: true },
  '/setdelay': { handler: commands.setDelayCommand },
  
  '/setmessage': { handler: commands.setMessageCommand },
  '/addmessage': { handler: commands.addMessageCommand },
  '/removemessage': { handler: commands.removeMessageCommand },
  '/messages': { handler: commands.messagesCommand },
  '/setactive': { handler: commands.setActiveMessageCommand },
  '/activemessage': { handler: commands.activeMessageCommand },
  
  '/enablemulti': { handler: commands.enableMultipleMessagesCommand },
  '/disablemulti': { handler: commands.disableMultipleMessagesCommand },
  '/addtoactive': { handler: commands.addToActiveMessagesCommand },
  '/removefromactive': { handler: commands.removeFromActiveMessagesCommand },
  '/activelist': { handler: commands.listActiveMessagesCommand },
  
  '/addadmin': { handler: commands.addAdminCommand },
  '/removeadmin': { handler: commands.removeAdminCommand },
  '/admins': { handler: commands.adminsCommand },
  
  '/addchat': { handler: commands.addChatCommand },
  '/removechat': { handler: commands.removeChatCommand },
  '/chats': { handler: commands.chatsCommand },
  '/peerid': { handler: commands.peerIdCommand },
  
  '/enablelog': { handler: commands.enableLogCommand },
  '/disablelog': { handler: commands.disableLogCommand }, 
  '/settoken': { handler: commands.setTokenCommand },
  '/help': { handler: commands.helpCommand }
};

vk.updates.on('message_new', async (ctx) => {
  if (!ctx.text || !ctx.text.startsWith('/')) return;

  try {
    if (!ctx.senderId && ctx.senderType === 'user') {
      ctx.senderId = ctx.senderId || ctx.userId || ctx.from_id;
    }

    if (ctx.hasReplyMessage && !ctx.replyMessage) {
      try {
        await ctx.loadMessagePayload();
      } catch (error) {
        console.error('Ошибка загрузки ответа на сообщение:', error.message);
      }
    }

    if (ctx.hasForwards && (!ctx.forwards || ctx.forwards.length === 0)) {
      try {
        await ctx.loadMessagePayload();
      } catch (error) {
        console.error('Ошибка загрузки пересылаемых сообщений:', error.message);
      }
    }

    const commandName = ctx.text.split(' ')[0].toLowerCase();

    const command = COMMAND_HANDLERS[commandName];
    
    if (command) {
      if (command.needsAdvertisementManager) {
        await command.handler(ctx, config, advertisementManager);
      } else {
        await command.handler(ctx, config);
      }
    } else if (isAdmin(ctx.senderId, config)) {
      await ctx.reply('❌ Неизвестная команда. Используйте /help для просмотра списка команд.');
    }
  } catch (error) {
    log(`Ошибка при обработке команды: ${error.message}`, config);
    console.error('Ошибка при обработке команды:', error);
    if (isAdmin(ctx.senderId, config)) {
      await ctx.reply(`❌ Произошла ошибка при выполнении команды: ${error.message}`);
    }
  }
});

const startBot = async () => {
  try {
    await vk.updates.start();
    console.log('VK Advertiser Bot запущен!');
    log('Бот успешно запущен', config);

    if (config.isRunning) {
      advertisementManager.start();
      log('Автоматически возобновлена рассылка при запуске', config);
    }
  } catch (error) {
    console.error('Ошибка при запуске бота:', error.message);
    process.exit(1);
  }
};

const shutdown = () => {
  advertisementManager.stop();
  saveConfig(config);
  log('Бот остановлен', config);
  process.exit(0);
};

process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);

startBot(); 