const fs = require('fs-extra');
const path = require('path');


const defaultConfig = {
  token: process.env.VK_TOKEN || '',
  adminIds: [],
  message: 'письки попки',
  messages: [],
  activeMessageIndex: 0,
  activeMessageIndexes: [],
  useMultipleMessages: false,
  delay: 3600,
  loggingEnabled: true,
  chats: [],
  isRunning: false
};


const configPath = path.join(__dirname, 'config.json');


const loadConfig = () => {
  try {
    if (fs.existsSync(configPath)) {
      const config = fs.readJsonSync(configPath);
      
      
      
      if (config.message && (!config.messages || config.messages.length === 0)) {
        config.messages = [config.message];
        config.activeMessageIndex = 0;
      }
      
      
      
      if (!config.activeMessageIndexes) {
        config.activeMessageIndexes = [];
      }
      
      
      if (config.useMultipleMessages === undefined) {
        config.useMultipleMessages = false;
      }
      
      return { ...defaultConfig, ...config };
    }
  } catch (error) {
    console.error('Error loading config:', error.message);
  }
  
  
  saveConfig(defaultConfig);
  return defaultConfig;
};


const saveConfig = (config) => {
  try {
    fs.writeJsonSync(configPath, config, { spaces: 2 });
    return true;
  } catch (error) {
    console.error('Error saving config:', error.message);
    return false;
  }
};


const isAdmin = (userId, config) => {
  return config.adminIds.includes(userId);
};


const addAdmin = (userId, config) => {
  if (!config.adminIds.includes(userId)) {
    config.adminIds.push(userId);
    saveConfig(config);
    return true;
  }
  return false;
};


const removeAdmin = (userId, config) => {
  const index = config.adminIds.indexOf(userId);
  if (index !== -1) {
    config.adminIds.splice(index, 1);
    saveConfig(config);
    return true;
  }
  return false;
};


const addMessage = (messageText, config) => {
  if (messageText && !config.messages.includes(messageText)) {
    config.messages.push(messageText);
    saveConfig(config);
    return config.messages.length - 1; 
  }
  return -1;
};


const removeMessage = (index, config) => {
  if (index >= 0 && index < config.messages.length) {
    config.messages.splice(index, 1);
    
    
    if (config.activeMessageIndex >= config.messages.length) {
      config.activeMessageIndex = Math.max(0, config.messages.length - 1);
    }
    
    
    config.activeMessageIndexes = config.activeMessageIndexes.filter(idx => idx !== index)
      .map(idx => idx > index ? idx - 1 : idx); 
    
    saveConfig(config);
    return true;
  }
  return false;
};


const getActiveMessage = (config) => {
  if (config.messages.length === 0) {
    return config.message; 
  }
  return config.messages[config.activeMessageIndex];
};


const setActiveMessage = (index, config) => {
  if (index >= 0 && index < config.messages.length) {
    config.activeMessageIndex = index;
    saveConfig(config);
    return true;
  }
  return false;
};


const addToActiveMessages = (index, config) => {
  if (index >= 0 && index < config.messages.length && 
      !config.activeMessageIndexes.includes(index)) {
    config.activeMessageIndexes.push(index);
    saveConfig(config);
    return true;
  }
  return false;
};


const removeFromActiveMessages = (index, config) => {
  const position = config.activeMessageIndexes.indexOf(index);
  if (position !== -1) {
    config.activeMessageIndexes.splice(position, 1);
    saveConfig(config);
    return true;
  }
  return false;
};


const enableMultipleMessages = (config) => {
  config.useMultipleMessages = true;
  saveConfig(config);
  return true;
};


const disableMultipleMessages = (config) => {
  config.useMultipleMessages = false;
  saveConfig(config);
  return true;
};


const getNextMessage = (config, currentIndex = 0) => {
  if (!config.useMultipleMessages || config.activeMessageIndexes.length === 0) {
    
    return getActiveMessage(config);
  }
  
  
  if (currentIndex >= config.activeMessageIndexes.length) {
    currentIndex = 0;
  }
  
  const msgIndex = config.activeMessageIndexes[currentIndex];
  return config.messages[msgIndex];
};

module.exports = {
  loadConfig,
  saveConfig,
  isAdmin,
  addAdmin,
  removeAdmin,
  addMessage,
  removeMessage,
  getActiveMessage,
  setActiveMessage,
  addToActiveMessages,
  removeFromActiveMessages,
  enableMultipleMessages,
  disableMultipleMessages,
  getNextMessage
}; 