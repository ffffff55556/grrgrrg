const fs = require('fs-extra');
const path = require('path');

class Logger {
  constructor() {
    this.logFilePath = path.join(__dirname, 'log.txt');
    
    this.LOG_LEVELS = {
      INFO: 'INFO',
      WARNING: 'WARNING',
      ERROR: 'ERROR',
      SUCCESS: 'SUCCESS',
      SYSTEM: 'SYSTEM'
    };
    
    this.initLogFile();
  }

  initLogFile() {
    try {
      if (!fs.existsSync(this.logFilePath)) {
        fs.writeFileSync(this.logFilePath, '--- VK Advertiser Log ---\n');
        console.log(`Log file initialized at ${this.logFilePath}`);
      }
    } catch (error) {
      console.error('Error initializing log file:', error.message);
    }
  }

  addLog(message, config, level = 'INFO') {
    if (!config || !config.loggingEnabled) return;
    
    try {
      const timestamp = new Date().toISOString();
      const levelStr = level.padEnd(7);
      const logMessage = `[${timestamp}] [${levelStr}] ${message}\n`;
      
      fs.appendFileSync(this.logFilePath, logMessage);
      
      let consoleMessage = logMessage.trim();
      
      switch (level) {
        case this.LOG_LEVELS.ERROR:
          console.error(consoleMessage);
          break;
        case this.LOG_LEVELS.WARNING:
          console.warn(consoleMessage);
          break;
        case this.LOG_LEVELS.SUCCESS:
        case this.LOG_LEVELS.SYSTEM:
          console.info(consoleMessage);
          break;
        default:
          console.log(consoleMessage);
      }
    } catch (error) {
      console.error('Error logging message:', error.message);
    }
  }

  info(message, config) {
    this.addLog(message, config, this.LOG_LEVELS.INFO);
  }

  warning(message, config) {
    this.addLog(message, config, this.LOG_LEVELS.WARNING);
  }

  error(message, config) {
    this.addLog(message, config, this.LOG_LEVELS.ERROR);
  }

  success(message, config) {
    this.addLog(message, config, this.LOG_LEVELS.SUCCESS);
  }

  system(message) {
    this.addLog(message, { loggingEnabled: true }, this.LOG_LEVELS.SYSTEM);
  }
}

const logger = new Logger();

const log = (message, config) => {
  logger.info(message, config);
};

module.exports = { 
  log,
  logger
}; 