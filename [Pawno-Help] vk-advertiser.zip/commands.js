const { saveConfig, isAdmin, addAdmin, removeAdmin, addMessage, removeMessage, getActiveMessage, setActiveMessage, addToActiveMessages, removeFromActiveMessages, enableMultipleMessages, disableMultipleMessages } = require('./config');
const { log } = require('./logger');

class MessageContext {
  static extractUserId(ctx, args = []) {
    if (args.length > 0 && !isNaN(args[0])) {
      return { success: true, userId: parseInt(args[0]) };
    }
    
    try {
      if (ctx.replyMessage && ctx.replyMessage.senderId) {
        return { success: true, userId: ctx.replyMessage.senderId };
      }
      
      if (ctx.forwards && ctx.forwards.length > 0) {
        const forward = ctx.forwards[0];
        if (forward && forward.senderId) {
          return { success: true, userId: forward.senderId };
        }
      }
      
      const mentionMatch = ctx.text ? ctx.text.match(/@id(\d+)/) : null;
      if (mentionMatch && mentionMatch[1]) {
        return { success: true, userId: parseInt(mentionMatch[1]) };
      }
      
      return { 
        success: false, 
        error: 'Не удалось определить ID пользователя. Укажите ID явно, ответьте на сообщение пользователя, перешлите его сообщение или упомяните его (@id123456).' 
      };
    } catch (error) {
      return { 
        success: false, 
        error: `Ошибка при определении ID пользователя: ${error.message}`
      };
    }
  }

  static extractChatId(ctx, args = []) {
    if (args.length > 0 && !isNaN(args[0])) {
      return { success: true, chatId: parseInt(args[0]) };
    }

    try {
      if (ctx.peerId && ctx.peerId > 2000000000) {
        return { success: true, chatId: ctx.peerId };
      }
      
      if (ctx.forwards && ctx.forwards.length > 0) {
        const forward = ctx.forwards[0];
        if (forward && forward.peerId && forward.peerId > 2000000000) {
          return { success: true, chatId: forward.peerId };
        }
      }
      
      if (ctx.replyMessage && ctx.replyMessage.peerId && ctx.replyMessage.peerId > 2000000000) {
        return { success: true, chatId: ctx.replyMessage.peerId };
      }
      
      if (ctx.isUser && ctx.peerId) {
        return { success: true, chatId: ctx.peerId };
      }
      
      return {
        success: false,
        error: 'Не удалось определить ID чата. Укажите ID чата явно или выполните команду в нужном чате.'
      };
    } catch (error) {
      return {
        success: false,
        error: `Ошибка при определении ID чата: ${error.message}`
      };
    }
  }

  static extractText(ctx, command) {
    if (!ctx.text) return '';

    let text = ctx.text.replace(new RegExp(`^${command}\\s+`), '').trim();
    
    if (!text && ctx.replyMessage && ctx.replyMessage.text) {
      text = ctx.replyMessage.text;
    }
    
    if (!text && ctx.forwards && ctx.forwards.length > 0) {
      text = ctx.forwards[0].text || '';
    }
    
    return text;
  }
}

class Command {
  constructor() {
    this.requiresAdmin = true;
  }
  
  async checkAdminPermission(ctx, config) {
    if (this.requiresAdmin && !isAdmin(ctx.senderId, config)) {
      await ctx.reply('❌ У вас нет прав администратора для использования этой команды.');
      return false;
    }
    return true;
  }
  
  logCommand(message, ctx, config) {
    log(`${message} [${ctx.senderId}]`, config);
  }
}

class AdvertisementCommands {
  static async start(ctx, config, advertisementManager) {
    if (!isAdmin(ctx.senderId, config)) {
      return ctx.reply('❌ У вас нет прав администратора для использования этой команды.');
    }

    if (config.isRunning) {
      return ctx.reply('⚠️ Рассылка уже запущена!');
    }

    if (config.chats.length === 0) {
      return ctx.reply('❌ Список чатов для рассылки пуст. Добавьте чаты с помощью команды /addchat.');
    }

    if (config.messages.length === 0 && !config.message) {
      return ctx.reply('❌ Нет сообщений для рассылки. Добавьте хотя бы одно сообщение с помощью /addmessage.');
    }

    config.isRunning = true;
    saveConfig(config);
    log(`Рассылка запущена администратором ${ctx.senderId}`, config);
    
    advertisementManager.start();
    return ctx.reply('✅ Рассылка успешно запущена!');
  }

  static async stop(ctx, config, advertisementManager) {
    if (!isAdmin(ctx.senderId, config)) {
      return ctx.reply('❌ У вас нет прав администратора для использования этой команды.');
    }

    if (!config.isRunning) {
      return ctx.reply('⚠️ Рассылка уже остановлена!');
    }

    config.isRunning = false;
    saveConfig(config);
    log(`Рассылка остановлена администратором ${ctx.senderId}`, config);
    
    advertisementManager.stop();
    return ctx.reply('✅ Рассылка успешно остановлена!');
  }

  static async setDelay(ctx, config) {
    if (!isAdmin(ctx.senderId, config)) {
      return ctx.reply('❌ У вас нет прав администратора для использования этой команды.');
    }

    const args = ctx.text.split(' ').slice(1);
    if (args.length !== 1 || isNaN(args[0]) || parseInt(args[0]) < 1) {
      return ctx.reply('❌ Неверный формат команды. Используйте: /setdelay [секунды]');
    }

    const newDelay = parseInt(args[0]);
    config.delay = newDelay;
    saveConfig(config);
    log(`Задержка между сообщениями изменена на ${newDelay} секунд администратором ${ctx.senderId}`, config);
    
    return ctx.reply(`✅ Задержка между сообщениями установлена на ${newDelay} секунд!`);
  }
}

class MessageCommands {
  static async setMessage(ctx, config) {
    if (!isAdmin(ctx.senderId, config)) {
      return ctx.reply('❌ У вас нет прав администратора для использования этой команды.');
    }

    const messageText = MessageContext.extractText(ctx, '/setmessage');
    if (!messageText) {
      return ctx.reply('❌ Неверный формат команды. Используйте: /setmessage [текст сообщения] или ответьте на сообщение с текстом.');
    }

    config.message = messageText;
    
    if (!config.messages.includes(messageText)) {
      config.messages.push(messageText);
      config.activeMessageIndex = config.messages.length - 1;
    } else {
      config.activeMessageIndex = config.messages.indexOf(messageText);
    }
    
    saveConfig(config);
    log(`Текст рассылки изменен администратором ${ctx.senderId}`, config);
    
    return ctx.reply(`✅ Текст рассылки успешно обновлен!`);
  }

  static async addMessage(ctx, config) {
    if (!isAdmin(ctx.senderId, config)) {
      return ctx.reply('❌ У вас нет прав администратора для использования этой команды.');
    }

    const messageText = MessageContext.extractText(ctx, '/addmessage');
    if (!messageText) {
      return ctx.reply('❌ Неверный формат команды. Используйте: /addmessage [текст сообщения] или ответьте на сообщение с текстом.');
    }

    if (config.messages.includes(messageText)) {
      return ctx.reply('⚠️ Данное сообщение уже существует в списке!');
    }

    const index = addMessage(messageText, config);
    if (index === -1) {
      return ctx.reply('❌ Не удалось добавить сообщение.');
    }
    
    log(`Добавлено новое сообщение (№${index + 1}) администратором ${ctx.senderId}`, config);
    return ctx.reply(`✅ Сообщение успешно добавлено под номером ${index + 1}!`);
  }

  static async removeMessage(ctx, config) {
    if (!isAdmin(ctx.senderId, config)) {
      return ctx.reply('❌ У вас нет прав администратора для использования этой команды.');
    }

    const args = ctx.text.split(' ').slice(1);
    if (args.length !== 1 || isNaN(args[0]) || parseInt(args[0]) < 1) {
      return ctx.reply('❌ Неверный формат команды. Используйте: /removemessage [номер]');
    }

    const index = parseInt(args[0]) - 1;
    
    if (config.messages.length === 1) {
      return ctx.reply('❌ Невозможно удалить единственное сообщение. Сначала добавьте другое сообщение.');
    }

    if (removeMessage(index, config)) {
      log(`Удалено сообщение №${index + 1} администратором ${ctx.senderId}`, config);
      return ctx.reply(`✅ Сообщение №${index + 1} успешно удалено!`);
    } else {
      return ctx.reply(`❌ Сообщение с номером ${index + 1} не найдено.`);
    }
  }

  static async listMessages(ctx, config) {
    if (!isAdmin(ctx.senderId, config)) {
      return ctx.reply('❌ У вас нет прав администратора для использования этой команды.');
    }

    if (config.messages.length === 0) {
      return ctx.reply('📋 Список сообщений пуст.');
    }

    const activeIndex = config.activeMessageIndex;
    const messagesList = config.messages.map((message, index) => {
      const activeMarker = index === activeIndex ? '✅ ' : '';
      return `${activeMarker}${index + 1}. ${message.substring(0, 50)}${message.length > 50 ? '...' : ''}`;
    }).join('\n\n');
    
    return ctx.reply(`📋 Список сообщений для рассылки:\n\n${messagesList}`);
  }

  static async setActiveMessage(ctx, config) {
    if (!isAdmin(ctx.senderId, config)) {
      return ctx.reply('❌ У вас нет прав администратора для использования этой команды.');
    }

    const args = ctx.text.split(' ').slice(1);
    if (args.length !== 1 || isNaN(args[0]) || parseInt(args[0]) < 1) {
      return ctx.reply('❌ Неверный формат команды. Используйте: /setactive [номер]');
    }

    const index = parseInt(args[0]) - 1;
    
    if (setActiveMessage(index, config)) {
      log(`Изменено активное сообщение на №${index + 1} администратором ${ctx.senderId}`, config);
      return ctx.reply(`✅ Сообщение №${index + 1} установлено как активное!`);
    } else {
      return ctx.reply(`❌ Сообщение с номером ${index + 1} не найдено.`);
    }
  }

  static async showActiveMessage(ctx, config) {
    if (!isAdmin(ctx.senderId, config)) {
      return ctx.reply('❌ У вас нет прав администратора для использования этой команды.');
    }

    if (config.messages.length === 0) {
      return ctx.reply('📋 Список сообщений пуст.');
    }

    const activeMessage = getActiveMessage(config);
    const activeIndex = config.activeMessageIndex;
    
    return ctx.reply(`📋 Активное сообщение (№${activeIndex + 1}):\n\n${activeMessage}`);
  }
  
  static async enableMultipleMessages(ctx, config) {
    if (!isAdmin(ctx.senderId, config)) {
      return ctx.reply('❌ У вас нет прав администратора для использования этой команды.');
    }
    
    if (config.useMultipleMessages) {
      return ctx.reply('⚠️ Режим отправки нескольких сообщений уже включен!');
    }
    
    enableMultipleMessages(config);
    log(`Включен режим отправки нескольких сообщений администратором ${ctx.senderId}`, config);
    
    if (config.activeMessageIndexes.length === 0) {
      return ctx.reply('✅ Режим отправки нескольких сообщений включен!\n\n⚠️ Внимание: не выбрано ни одного сообщения для последовательной отправки. Используйте /addtoactive [номер] для добавления сообщений.');
    }
    
    return ctx.reply(`✅ Режим отправки нескольких сообщений включен! Будет отправлено ${config.activeMessageIndexes.length} сообщений поочередно.`);
  }
  
  static async disableMultipleMessages(ctx, config) {
    if (!isAdmin(ctx.senderId, config)) {
      return ctx.reply('❌ У вас нет прав администратора для использования этой команды.');
    }
    
    if (!config.useMultipleMessages) {
      return ctx.reply('⚠️ Режим отправки нескольких сообщений уже выключен!');
    }
    
    disableMultipleMessages(config);
    log(`Выключен режим отправки нескольких сообщений администратором ${ctx.senderId}`, config);
    
    return ctx.reply('✅ Режим отправки нескольких сообщений выключен! Будет использоваться только активное сообщение.');
  }
  
  static async addToActiveMessages(ctx, config) {
    if (!isAdmin(ctx.senderId, config)) {
      return ctx.reply('❌ У вас нет прав администратора для использования этой команды.');
    }
    
    const args = ctx.text.split(' ').slice(1);
    if (args.length !== 1 || isNaN(args[0]) || parseInt(args[0]) < 1) {
      return ctx.reply('❌ Неверный формат команды. Используйте: /addtoactive [номер]');
    }
    
    const index = parseInt(args[0]) - 1;
    
    if (index < 0 || index >= config.messages.length) {
      return ctx.reply(`❌ Сообщение с номером ${index + 1} не найдено.`);
    }
    
    if (config.activeMessageIndexes.includes(index)) {
      return ctx.reply('⚠️ Данное сообщение уже добавлено в список для отправки!');
    }
    
    addToActiveMessages(index, config);
    log(`Добавлено сообщение №${index + 1} в список активных сообщений администратором ${ctx.senderId}`, config);
    
    return ctx.reply(`✅ Сообщение №${index + 1} добавлено в список для поочередной отправки.\n\nВсего активных сообщений: ${config.activeMessageIndexes.length}`);
  }
  
  static async removeFromActiveMessages(ctx, config) {
    if (!isAdmin(ctx.senderId, config)) {
      return ctx.reply('❌ У вас нет прав администратора для использования этой команды.');
    }
    
    const args = ctx.text.split(' ').slice(1);
    if (args.length !== 1 || isNaN(args[0]) || parseInt(args[0]) < 1) {
      return ctx.reply('❌ Неверный формат команды. Используйте: /removefromactive [номер]');
    }
    
    const index = parseInt(args[0]) - 1;
    
    if (!config.activeMessageIndexes.includes(index)) {
      return ctx.reply(`❌ Сообщение №${index + 1} не найдено в списке активных сообщений.`);
    }
    
    removeFromActiveMessages(index, config);
    log(`Удалено сообщение №${index + 1} из списка активных сообщений администратором ${ctx.senderId}`, config);
    
    let reply = `✅ Сообщение №${index + 1} удалено из списка для поочередной отправки.`;
    
    if (config.activeMessageIndexes.length === 0) {
      reply += '\n\n⚠️ Внимание: список активных сообщений пуст. Режим множественной отправки не будет работать без выбранных сообщений.';
    } else {
      reply += `\n\nВсего активных сообщений: ${config.activeMessageIndexes.length}`;
    }
    
    return ctx.reply(reply);
  }
  
  static async listActiveMessages(ctx, config) {
    if (!isAdmin(ctx.senderId, config)) {
      return ctx.reply('❌ У вас нет прав администратора для использования этой команды.');
    }
    
    if (config.activeMessageIndexes.length === 0) {
      return ctx.reply('📋 Список активных сообщений для поочередной отправки пуст. Добавьте сообщения с помощью /addtoactive [номер].');
    }
    
    const activeMessagesList = config.activeMessageIndexes.map((index, position) => {
      const message = config.messages[index];
      return `${position + 1}. (#${index + 1}) ${message.substring(0, 50)}${message.length > 50 ? '...' : ''}`;
    }).join('\n\n');
    
    const statusText = config.useMultipleMessages 
      ? '✅ Режим множественной отправки: включен' 
      : '❌ Режим множественной отправки: выключен';
    
    return ctx.reply(`📋 Список сообщений для поочередной отправки:\n\n${activeMessagesList}\n\n${statusText}\n\nПорядок в списке соответствует порядку отправки.`);
  }
}

class AdminCommands {
  static async addAdmin(ctx, config) {
    if (!isAdmin(ctx.senderId, config)) {
      if (config.adminIds.length === 0) {
        addAdmin(ctx.senderId, config);
        log(`Добавлен первый администратор: ${ctx.senderId}`, config);
        return ctx.reply(`✅ Вы стали первым администратором бота! Теперь вы можете управлять ботом.`);
      }
      return ctx.reply('❌ У вас нет прав администратора для использования этой команды.');
    }

    const args = ctx.text.split(' ').slice(1);
    const result = await MessageContext.extractUserId(ctx, args);

    if (!result.success) {
      return ctx.reply(result.error);
    }

    const newAdminId = result.userId;
    
    if (isAdmin(newAdminId, config)) {
      return ctx.reply(`⚠️ Пользователь с ID ${newAdminId} уже является администратором!`);
    }

    addAdmin(newAdminId, config);
    log(`Добавлен новый администратор: ${newAdminId} администратором ${ctx.senderId}`, config);
    
    return ctx.reply(`✅ Пользователь с ID ${newAdminId} успешно добавлен в список администраторов!`);
  }

  static async removeAdmin(ctx, config) {
    if (!isAdmin(ctx.senderId, config)) {
      return ctx.reply('❌ У вас нет прав администратора для использования этой команды.');
    }

    const args = ctx.text.split(' ').slice(1);
    const result = await MessageContext.extractUserId(ctx, args);

    if (!result.success) {
      return ctx.reply(result.error);
    }

    const adminId = result.userId;
    
    if (adminId === ctx.senderId && config.adminIds.length === 1) {
      return ctx.reply('⚠️ Вы не можете удалить самого себя, если вы единственный администратор!');
    }
    
    if (!isAdmin(adminId, config)) {
      return ctx.reply(`⚠️ Пользователь с ID ${adminId} не является администратором!`);
    }

    removeAdmin(adminId, config);
    log(`Удален администратор: ${adminId} администратором ${ctx.senderId}`, config);
    
    return ctx.reply(`✅ Пользователь с ID ${adminId} успешно удален из списка администраторов!`);
  }

  static async listAdmins(ctx, config) {
    if (!isAdmin(ctx.senderId, config)) {
      return ctx.reply('❌ У вас нет прав администратора для использования этой команды.');
    }

    if (config.adminIds.length === 0) {
      return ctx.reply('📋 Список администраторов пуст.');
    }

    const adminsList = config.adminIds.map((adminId, index) => `${index + 1}. ${adminId}`).join('\n');
    return ctx.reply(`👑 Список администраторов:\n${adminsList}`);
  }
}

class ChatCommands {
  static async addChat(ctx, config) {
    if (!isAdmin(ctx.senderId, config)) {
      return ctx.reply('❌ У вас нет прав администратора для использования этой команды.');
    }

    const args = ctx.text.split(' ').slice(1);
    const result = MessageContext.extractChatId(ctx, args);
    
    if (!result.success) {
      return ctx.reply(result.error);
    }
    
    const chatId = result.chatId;

    if (config.chats.includes(chatId)) {
      return ctx.reply('⚠️ Данный чат уже добавлен в список рассылки!');
    }

    config.chats.push(chatId);
    saveConfig(config);
    log(`Добавлен новый чат в список рассылки: ${chatId} администратором ${ctx.senderId}`, config);
    
    return ctx.reply(`✅ Чат с ID ${chatId} успешно добавлен в список рассылки!`);
  }

  static async removeChat(ctx, config) {
    if (!isAdmin(ctx.senderId, config)) {
      return ctx.reply('❌ У вас нет прав администратора для использования этой команды.');
    }

    const args = ctx.text.split(' ').slice(1);
    const result = MessageContext.extractChatId(ctx, args);
    
    if (!result.success) {
      return ctx.reply(result.error);
    }
    
    const chatId = result.chatId;

    const index = config.chats.indexOf(chatId);
    
    if (index === -1) {
      return ctx.reply('⚠️ Данный чат не найден в списке рассылки!');
    }

    config.chats.splice(index, 1);
    saveConfig(config);
    log(`Удален чат из списка рассылки: ${chatId} администратором ${ctx.senderId}`, config);
    
    return ctx.reply(`✅ Чат с ID ${chatId} успешно удален из списка рассылки!`);
  }

  static async listChats(ctx, config) {
    if (!isAdmin(ctx.senderId, config)) {
      return ctx.reply('❌ У вас нет прав администратора для использования этой команды.');
    }

    if (config.chats.length === 0) {
      return ctx.reply('📋 Список чатов для рассылки пуст.');
    }

    const chatsList = config.chats.map((chatId, index) => `${index + 1}. ${chatId}`).join('\n');
    return ctx.reply(`📋 Список чатов для рассылки:\n${chatsList}`);
  }

  static async getPeerId(ctx, config) {
    const peerId = ctx.peerId;
    
    if (!peerId) {
      return ctx.reply('❌ Не удалось определить ID чата.');
    }
    
    log(`Запрос ID чата от пользователя ${ctx.senderId}`, config);
    return ctx.reply(`🆔 ID текущего чата: ${peerId}\n\nВы можете использовать его с командой /addchat для добавления в список рассылки.`);
  }
}

class SystemCommands {
  static async enableLog(ctx, config) {
    if (!isAdmin(ctx.senderId, config)) {
      return ctx.reply('❌ У вас нет прав администратора для использования этой команды.');
    }

    if (config.loggingEnabled) {
      return ctx.reply('⚠️ Логирование уже включено!');
    }

    config.loggingEnabled = true;
    saveConfig(config);
    log(`Логирование включено администратором ${ctx.senderId}`, config);
    
    return ctx.reply('✅ Логирование успешно включено!');
  }

  static async disableLog(ctx, config) {
    if (!isAdmin(ctx.senderId, config)) {
      return ctx.reply('❌ У вас нет прав администратора для использования этой команды.');
    }

    if (!config.loggingEnabled) {
      return ctx.reply('⚠️ Логирование уже выключено!');
    }

    config.loggingEnabled = false;
    saveConfig(config);
    log(`Логирование выключено администратором ${ctx.senderId}`, config);
    
    return ctx.reply('✅ Логирование успешно выключено!');
  }

  static async setToken(ctx, config) {
    if (!isAdmin(ctx.senderId, config)) {
      return ctx.reply('❌ У вас нет прав администратора для использования этой команды.');
    }

    const tokenText = ctx.text.substring(ctx.text.indexOf(' ') + 1).trim();
    if (!tokenText) {
      return ctx.reply('❌ Неверный формат команды. Используйте: /settoken [токен]');
    }

    config.token = tokenText;
    saveConfig(config);
    log(`Токен VK API изменен администратором ${ctx.senderId}`, config);
    
    return ctx.reply(`✅ Токен VK API успешно обновлен! Для применения изменений перезапустите бота.`);
  }

  static async help(ctx, config) {
    const isUserAdmin = isAdmin(ctx.senderId, config);
    
    let helpText = `
📝 Список доступных команд:
`;

    if (isUserAdmin) {
      helpText += `
🔹 /start — ▶️ Запустить рассылку
🔹 /stop — ⏹ Остановить
🔹 /setdelay [секунды] — ⏳ Задержка между сообщениями
🔹 /setmessage [текст] — 📝 Изменить текст рассылки (старый метод)

📝 Управление сообщениями:
🔹 /addmessage [текст] — ➕ Добавить новое сообщение в список
🔹 /removemessage [номер] — ➖ Удалить сообщение из списка
🔹 /messages — 📋 Показать список всех сообщений
🔹 /setactive [номер] — ✅ Установить активное сообщение для рассылки
🔹 /activemessage — 📄 Показать текущее активное сообщение

📊 Отправка нескольких сообщений:
🔹 /enablemulti — ✅ Включить режим отправки нескольких сообщений
🔹 /disablemulti — ❌ Выключить режим отправки нескольких сообщений
🔹 /addtoactive [номер] — ➕ Добавить сообщение в очередь для отправки
🔹 /removefromactive [номер] — ➖ Удалить сообщение из очереди для отправки
🔹 /activelist — 📋 Показать список сообщений для отправки

👑 Управление администраторами:
🔹 /addadmin [id пользователя] — 👑 Добавить администратора
🔹 /removeadmin [id пользователя] — 👑 Удалить администратора
🔹 /admins — 👥 Показать список администраторов

📋 Управление чатами:
🔹 /addchat [id чата] — ➕ Добавить чат в список рассылки
🔹 /removechat [id чата] — ➖ Удалить чат из списка рассылки
🔹 /chats — 📋 Показать текущие чаты для рассылки
🔹 /peerid — 🆔 Показать ID текущего чата

⚙️ Настройки:
🔹 /enablelog — 🔔 Включить логирование
🔹 /disablelog — 🔕 Выключить логирование
🔹 /settoken [токен] — 🔑 Установить токен VK API
🔹 /help — ❓ Вывести список доступных команд
`;
    } else {
      if (config.adminIds.length === 0) {
        helpText += `
🔹 /addadmin — 👑 Стать первым администратором бота
`;
      } else {
        helpText += `
У вас нет прав администратора для использования команд бота.
`;
      }
    }
    
    return ctx.reply(helpText);
  }
}

module.exports = {
  startCommand: AdvertisementCommands.start,
  stopCommand: AdvertisementCommands.stop,
  setDelayCommand: AdvertisementCommands.setDelay,
  
  setMessageCommand: MessageCommands.setMessage,
  addMessageCommand: MessageCommands.addMessage,
  removeMessageCommand: MessageCommands.removeMessage,
  messagesCommand: MessageCommands.listMessages,
  setActiveMessageCommand: MessageCommands.setActiveMessage,
  activeMessageCommand: MessageCommands.showActiveMessage,
  enableMultipleMessagesCommand: MessageCommands.enableMultipleMessages,
  disableMultipleMessagesCommand: MessageCommands.disableMultipleMessages,
  addToActiveMessagesCommand: MessageCommands.addToActiveMessages,
  removeFromActiveMessagesCommand: MessageCommands.removeFromActiveMessages,
  listActiveMessagesCommand: MessageCommands.listActiveMessages,
  
  addAdminCommand: AdminCommands.addAdmin,
  removeAdminCommand: AdminCommands.removeAdmin,
  adminsCommand: AdminCommands.listAdmins,
  
  addChatCommand: ChatCommands.addChat,
  removeChatCommand: ChatCommands.removeChat,
  chatsCommand: ChatCommands.listChats,
  peerIdCommand: ChatCommands.getPeerId,
  
  enableLogCommand: SystemCommands.enableLog,
  disableLogCommand: SystemCommands.disableLog,
  setTokenCommand: SystemCommands.setToken,
  helpCommand: SystemCommands.help
};